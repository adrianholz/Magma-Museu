<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Z2} @OXQvcf,KS^o@M2>#H>`W1(E;KoW87#*g Oe(VpCxB;Uyir2fW)yW&00npM;' );
define( 'SECURE_AUTH_KEY',   '?h7n:2lsU@iyPo5}:;`T/[b{ge4:6FFjpX%Y973Ud]MGDKzmebb-r8KACxSJ9i?5' );
define( 'LOGGED_IN_KEY',     'GK:t_ecbsxFxH|[,$UvqQs[gZYRYqMc^^-,)_t:YQ{ahA1|aw(A)~}BY6m*9 q~b' );
define( 'NONCE_KEY',         'Q<$~<L[MhS)U0*J!10s~).D&wF/+p_bJfx1(99W>*xv^43YIms!NYy;up`e<mT+m' );
define( 'AUTH_SALT',         '%{p[9zWEZRhhH*{&7{!I-p0mqTFfNrD9@Ne|kSvBJ%>=yihc/RU!u>L0Q}T0:A%7' );
define( 'SECURE_AUTH_SALT',  'mk+a:#est}-X~6MY~EbXk-(-X [CGds~[s=$DZw<a[)ZMYign(kOQSX%o%[Tes)*' );
define( 'LOGGED_IN_SALT',    '7v#0:fUzbHP0VxvW}}4Go_{lwz=UC]4<YkWD%kPm&@59(9PE{/r)!X3E8?O1~ffr' );
define( 'NONCE_SALT',        'V%%,~FSoia7F;%KFMCy5B!jyU}VEmhlZNb{49.S*;JATppycu62x24mwx[n7Qq.z' );
define( 'WP_CACHE_KEY_SALT', 'Ws,!FO>]2fB7 #h47VuP|jgXay#.{bF^pdGb,,`;O^B3 :*l?{LaMpjFeN<h2>pT' );
define('JWT_AUTH_SECRET_KEY', 'N;K]&+,-b[lwuw/%cjl0^;%>m<%bQ&I?+B_{8yJg*NG>!DLcmVhIOcQ{{Y u80~#');
define('JWT_AUTH_CORS_ENABLE', true);


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
